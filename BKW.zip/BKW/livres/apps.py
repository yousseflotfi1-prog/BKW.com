from django.apps import AppConfig


class LivresConfig(AppConfig):
    name = 'livres'
