from django.contrib import admin

# Register your models here.
from .models import Livre, Categorie

class LivreAdmin(admin.ModelAdmin):
    list_display = ('titre', 'auteur', 'prix', 'stock', 'categorie', 'date_ajout')
    search_fields = ('titre', 'auteur')
    list_filter = ('categorie',)

admin.site.register(Livre, LivreAdmin)
admin.site.register(Categorie)
