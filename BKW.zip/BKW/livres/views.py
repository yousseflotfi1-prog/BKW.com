from django.shortcuts import render

# Create your views here.
from .models import Livre, Categorie

#def liste_livres(request):
#    livres = Livre.objects.all().order_by('-date_ajout')
#    return render(request, 'livres.html', {'livres': livres})
def liste_livres(request):
    query = request.GET.get('q')
    categorie_id = request.GET.get('categorie')

    livres = Livre.objects.all()

    if query:
        livres = livres.filter(
            titre__icontains=query
        ) | livres.filter(
            auteur__icontains=query
        )

    if categorie_id:
        livres = livres.filter(categorie_id=categorie_id)

    categories = Categorie.objects.all()

    return render(request, 'livres.html', {
        'livres': livres,
        'categories': categories
    })
from django.shortcuts import get_object_or_404
def detail_livre(request, livre_id):
    livre = get_object_or_404(Livre, pk=livre_id)
    return render(request, 'detail_livre.html', {'livre': livre})
